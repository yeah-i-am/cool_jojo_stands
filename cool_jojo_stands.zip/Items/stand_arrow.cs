using Microsoft.Xna.Framework;
using System;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace cool_jojo_stands.Items
{
	public class stand_arrow : ModItem
	{
        string[] stands =
        {
          "StarPlatinumStand"
        };

        public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Stand arrow");
			Tooltip.SetDefault("��� ��������� �������������.");
		}
		public override void SetDefaults()
		{
			item.damage = 99;
			item.noMelee = true;
			item.width = 40;
			item.height = 40;
			item.useTime = 20;
			item.useAnimation = 21;
			item.useStyle = 2;
			item.knockBack = 0;
			item.value = Item.buyPrice(0, 4, 70, 0);
			item.rare = 11;
            item.expert = true;
			item.UseSound = SoundID.Item1;
			item.autoReuse = false;
	}

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.DirtBlock, 47);
			recipe.AddTile(TileID.WorkBenches);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}

        public override bool UseItem( Player player )
        {
            if (player.GetModPlayer<StandoPlayer>(mod).HaveStand)
              return base.UseItem(player);

            Random rand = new Random();

            player.AddBuff(mod.BuffType(stands[rand.Next(stands.Length)]), 600);
            return base.UseItem(player);
        }
    }
}
