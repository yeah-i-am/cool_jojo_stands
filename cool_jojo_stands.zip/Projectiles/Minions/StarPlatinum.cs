﻿using Microsoft.Xna.Framework;
using System;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace cool_jojo_stands.Projectiles.Minions
{
    public class StarPlatinum : NearStand
    {
        public override void SetStaticDefaults()
        {
            Main.projFrames[projectile.type] = 1;
            DisplayName.SetDefault("Star Platinum");
            Main.projPet[projectile.type] = true;
        }

        public override void SetDefaults()
        {
            StandoPlayer player = new StandoPlayer();

            player.Talk("Yeah1");

            projectile.netImportant = true;
            projectile.width = 60;
            projectile.height = 80;
            projectile.friendly = true;
            projectile.light = 1.0f;
            projectile.penetrate = -1;
            projectile.timeLeft = 18000;
            projectile.tileCollide = false;
            projectile.melee = true;
            projectile.ignoreWater = true;
            
            player.Talk("Yeah2");
        }

        public override bool CanDamage()
        {
            return true;
        }

        public override bool MinionContactDamage()
        {
            return true;
        }
    }
}