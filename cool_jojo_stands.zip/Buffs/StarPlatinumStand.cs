﻿using Terraria;
using Terraria.GameInput;
using Terraria.ModLoader;

namespace cool_jojo_stands.Buffs
{
    public class StarPlatinumStand : ModBuff
    {
        public override void SetDefaults()
        {
            DisplayName.SetDefault("Вы обладатель Star Platinum");
            Description.SetDefault("Станд ближнего боя, любит ORAть");
            Main.buffNoSave[Type] = true; /// false
            Main.buffNoTimeDisplay[Type] = true;
        }

        public override void Update(Player player, ref int buffIndex)
        {
            StandoPlayer StandPlayer = player.GetModPlayer<StandoPlayer>(mod);

            StandPlayer.HaveStarPlatinum = true;
            player.buffTime[buffIndex] = 600;

            if (!StandPlayer.StandSpawned && cool_jojo_stands.StandSummonHT.JustPressed)
            {
                StandPlayer.StandSpawned = true;
                StandPlayer.StandJustSpawned = true;
                Projectile.NewProjectile(player.position.X + (float)(player.width / 2), player.position.Y + (float)(player.height / 2),
                    0f, 0f, mod.ProjectileType("StarPlatinum"), 47, 2.0f, Main.myPlayer, 0f, 0f);
            }
        }
    }

}